import React from 'react';

const ContactPage = () => (
  <div className="section-padding">
    <div className="container-custom">
      <h1 className="text-4xl font-heading font-bold text-brand-primary mb-8">Contact Us</h1>
      <p className="text-lg text-gray-700">Contact page content will be added here.</p>
    </div>
  </div>
);

export default ContactPage;
