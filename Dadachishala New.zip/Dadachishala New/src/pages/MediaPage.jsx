import React from 'react';

const MediaPage = () => (
  <div className="section-padding">
    <div className="container-custom">
      <h1 className="text-4xl font-heading font-bold mb-8">Media & News</h1>
      <p className="text-lg text-gray-700">Media page content will be added here.</p>
    </div>
  </div>
);

export default MediaPage;
