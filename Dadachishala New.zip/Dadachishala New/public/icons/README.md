# Apple Touch Icon Placeholder
# This file serves as a placeholder for the apple-touch-icon.png
# You should replace this with an actual 180x180 PNG image

# To create the actual PNG file, you can:
# 1. Use the favicon.svg as a base
# 2. Export it as a 180x180 PNG image
# 3. Save it as apple-touch-icon.png in the /public/icons/ folder

# For now, the favicon.svg will serve as the main icon
# Modern browsers support SVG favicons which are scalable and crisp
